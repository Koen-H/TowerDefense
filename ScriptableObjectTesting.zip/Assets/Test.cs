using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{

    void OnMouseDown()
    {
        Debug.Log("click");
        //Open upgrades
    }
    void OnMouseExit()
    {
        Debug.Log("click away");
    }
}
